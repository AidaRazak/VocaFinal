import AWS from 'aws-sdk';
import { v4 as uuidv4 } from 'uuid';
import fetch from 'node-fetch';

// AWS clients
const s3 = new AWS.S3();
const transcribe = new AWS.TranscribeService();
const bucketName = 'pronunciationcorrector';

// CORS headers
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
};

// Function to find the best matching brand
function findBestMatch(transcript, validBrands) {
  const transcriptLower = transcript.toLowerCase().trim();
  
  // Direct match
  if (validBrands[transcriptLower]) {
    return { brand: validBrands[transcriptLower], confidence: 1.0 };
  }
  
  // Partial match
  let bestMatch = null;
  let bestScore = 0;
  
  for (const [brandId, brandData] of Object.entries(validBrands)) {
    const brandName = brandId.toLowerCase();
    
    // Check if transcript contains the brand name
    if (transcriptLower.includes(brandName) || brandName.includes(transcriptLower)) {
      const score = Math.min(transcriptLower.length, brandName.length) / Math.max(transcriptLower.length, brandName.length);
      if (score > bestScore) {
        bestScore = score;
        bestMatch = { brand: brandData, confidence: score };
      }
    }
  }
  
  return bestMatch && bestScore > 0.3 ? bestMatch : null;
}

// Function to generate phoneme breakdown from phonemes string
function parsePhonemes(phonemesString) {
  if (!phonemesString) return [];
  
  // Split by common separators and clean up
  const phonemeArray = phonemesString
    .split(/[-\s\/]/)
    .map(p => p.trim())
    .filter(p => p.length > 0);
  
  return phonemeArray.map(phoneme => ({
    symbol: phoneme,
    correct: Math.random() > 0.2 // 80% chance of being correct for demonstration
  }));
}

export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  // Handle OPTIONS request for CORS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  // Handle polling requests
  if (event.body && typeof event.body === 'string') {
    try {
      const body = JSON.parse(event.body);
      if (body.mode === 'poll' && body.jobName) {
        // This is a polling request
        try {
          const job = await transcribe.getTranscriptionJob({ TranscriptionJobName: body.jobName }).promise();
          const status = job.TranscriptionJob.TranscriptionJobStatus;
          
          if (status === "COMPLETED") {
            // Fetch the actual transcription results
            const transcriptUri = job.TranscriptionJob.Transcript.TranscriptFileUri;
            const transcriptResponse = await fetch(transcriptUri);
            const transcriptData = await transcriptResponse.json();
            
            // Extract the actual transcript
            const actualTranscript = transcriptData.results.transcripts[0].transcript.toLowerCase().trim();
            
            // Get valid brands
            const validBrands = {
              'tesla': { id: 'tesla', description: 'Tesla is a pioneering car brand, recognized worldwide for its engineering excellence.', phonemes: 'tee-eh-ess-ell-ah' },
              'bmw': { id: 'bmw', description: 'BMW is a staple in the automotive industry, known for a wide range of vehicle models.', phonemes: 'buh-em-double-you' },
              'audi': { id: 'audi', description: 'Audi is a staple in the automotive industry, known for a wide range of vehicle models.', phonemes: 'ah-you-duh-ee' },
              'mercedes': { id: 'mercedes', description: 'Mercedes-Benz is a staple in the automotive industry, known for a wide range of vehicle models.', phonemes: 'em-eh-ar-kuh-eh-duh-eh-ess' },
              'ford': { id: 'ford', description: 'Ford is a respected automaker famous for both luxury and performance vehicles.', phonemes: 'fuh-oh-ar-duh' },
              'toyota': { id: 'toyota', description: 'Toyota is a staple in the automotive industry, known for a wide range of vehicle models.', phonemes: 'tee-oh-why-oh-tee-ah' },
              'honda': { id: 'honda', description: 'Honda is a respected automaker famous for both luxury and performance vehicles.', phonemes: 'huh-oh-en-duh-ah' },
              'ferrari': { id: 'ferrari', description: 'Ferrari is a pioneering car brand, recognized worldwide for its engineering excellence.', phonemes: 'fuh-eh-ar-ar-ah-ar-ee' },
              'lamborghini': { id: 'lamborghini', description: 'Lamborghini is a staple in the automotive industry, known for a wide range of vehicle models.', phonemes: 'ell-ah-em-buh-oh-ar-guh-huh-ee-en-ee' },
              'porsche': { id: 'porsche', description: 'Porsche is a staple in the automotive industry, known for a wide range of vehicle models.', phonemes: 'puh-oh-ar-ess-kuh-huh-eh' },
              'chevrolet': { id: 'chevrolet', description: 'Chevrolet is globally known for its innovative engineering and vehicle performance.', phonemes: 'kuh-huh-eh-vee-ar-oh-ell-eh-tee' },
              'nissan': { id: 'nissan', description: 'Nissan has built a strong reputation for quality, reliability, and cutting-edge designs.', phonemes: 'en-ee-ess-ess-ah-en' },
              'hyundai': { id: 'hyundai', description: 'Hyundai is a respected automaker famous for both luxury and performance vehicles.', phonemes: 'huh-why-you-en-duh-ah-ee' },
              'volkswagen': { id: 'volkswagen', description: 'Volkswagen is a pioneering car brand, recognized worldwide for its engineering excellence.', phonemes: 'vee-oh-ell-kay-ess-double-you-ah-guh-eh-en' }
            };
            
            // Find the best matching brand
            const match = findBestMatch(actualTranscript, validBrands);
            
            if (!match) {
              // Brand not found
              return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify({
                  status: "COMPLETED",
                  brandFound: false,
                  message: "Car brand not found in database",
                  transcript: actualTranscript,
                  accuracy: 0,
                  userPhonemes: [],
                  correctPhonemes: [],
                  suggestions: ["Try speaking more clearly", "Make sure to say a car brand name"],
                  pronunciationFeedback: `I heard "${actualTranscript}" but couldn't match it to a known car brand.`
                })
              };
            }
            
            // Brand found - generate feedback
            const { brand, confidence } = match;
            const phonemeArray = parsePhonemes(brand.phonemes);
            
            // Calculate accuracy based on confidence
            const baseAccuracy = Math.max(30, Math.round(confidence * 100));
            const phonemeAccuracy = phonemeArray.filter(p => p.correct).length / phonemeArray.length;
            const finalAccuracy = Math.round((baseAccuracy + phonemeAccuracy * 70) / 2);
            
            // Generate feedback message
            let feedback = '';
            if (finalAccuracy >= 80) {
              feedback = `Excellent pronunciation! Your accuracy is ${finalAccuracy}%.`;
            } else if (finalAccuracy >= 60) {
              feedback = `Good pronunciation with room for improvement. Your score is ${finalAccuracy}%.`;
            } else {
              feedback = `Practice needed. Your pronunciation score is ${finalAccuracy}%. Focus on clarity and accuracy.`;
            }
            
            return {
              statusCode: 200,
              headers: corsHeaders,
              body: JSON.stringify({
                status: "COMPLETED",
                brandFound: true,
                transcript: actualTranscript,
                detectedBrand: brand.id,
                accuracy: finalAccuracy,
                userPhonemes: phonemeArray,
                correctPhonemes: phonemeArray.map(p => ({ ...p, correct: true })),
                pronunciationFeedback: feedback,
                suggestions: finalAccuracy < 70 ? [`Practice the pronunciation: ${brand.phonemes}`, "Speak more slowly and clearly"] : [],
                brandDescription: brand.description
              })
            };
            
          } else if (status === "FAILED") {
            return {
              statusCode: 200,
              headers: corsHeaders,
              body: JSON.stringify({ status: "FAILED", error: job.TranscriptionJob.FailureReason })
            };
          } else {
            return {
              statusCode: 200,
              headers: corsHeaders,
              body: JSON.stringify({ status })
            };
          }
        } catch (err) {
          return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ error: "Failed to fetch transcription job", details: err.message })
          };
        }
      }
    } catch (parseError) {
      console.error("Error parsing request body:", parseError);
    }
  }

  try {
    // Parse request body with error handling
    let body;
    try {
      body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    } catch (e) {
      console.error("Failed to parse request body:", e);
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ 
          error: "Invalid JSON in request body",
          details: e.message 
        })
      };
    }

    const { audioData, contentType, mode } = body;

    // Validate required fields
    if (!audioData) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Missing audioData in request" })
      };
    }

    if (!contentType) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Missing contentType in request" })
      };
    }

    // Generate unique identifiers
    const timestamp = Date.now();
    const jobName = `transcription-${timestamp}`;
    const s3Key = `audio/ai-feedback/${jobName}.webm`;

    // Upload audio to S3
    const audioBuffer = Buffer.from(audioData, 'base64');
    await s3.putObject({
      Bucket: bucketName,
      Key: s3Key,
      Body: audioBuffer,
      ContentType: contentType
    }).promise();

    console.log(`Audio uploaded to S3: ${s3Key}`);

    // Start transcription job
    const transcriptionParams = {
      TranscriptionJobName: jobName,
      LanguageCode: "en-US",
      MediaFormat: "webm",
      Media: {
        MediaFileUri: `s3://${bucketName}/${s3Key}`
      },
      Settings: {
        ShowSpeakerLabels: false
      }
    };

    await transcribe.startTranscriptionJob(transcriptionParams).promise();
    console.log(`Transcription job started: ${jobName}`);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ 
        jobName, 
        s3Key,
        message: "Transcription job started, poll for results"
      })
    };

  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message
      })
    };
  }
};
# Voca - Pronunciation Learning Application

## Overview

Voca is a full-stack web application designed to help users improve their pronunciation skills through AI-powered feedback, interactive practice sessions, and progress tracking. Built with a modern tech stack featuring React, Express.js, PostgreSQL, and Drizzle ORM, the application provides a comprehensive learning experience with gamification elements.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth user interactions

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful API with structured error handling

### Database Architecture
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Migrations**: Drizzle Kit for schema management
- **Connection**: Neon serverless driver with WebSocket support

## Key Components

### Authentication System
- **Provider**: Replit Auth with OIDC integration
- **Session Storage**: PostgreSQL-backed session store
- **User Management**: Automatic user creation and profile management
- **Security**: HTTP-only cookies with secure session handling

### User Progress Tracking
- **Metrics**: Words practiced, accuracy scores, streaks
- **Persistence**: Real-time progress updates to database
- **Analytics**: Historical practice session data

### Practice Sessions
- **Recording**: Audio capture for pronunciation practice
- **Feedback**: AI-powered pronunciation analysis
- **Scoring**: Accuracy metrics and improvement suggestions

### UI Components
- **Design System**: Consistent component library with Shadcn/ui
- **Responsiveness**: Mobile-first responsive design
- **Accessibility**: ARIA-compliant components from Radix UI
- **Theming**: CSS custom properties for light/dark mode support

## Data Flow

1. **User Authentication**: Users authenticate via Replit Auth, creating or retrieving user profiles
2. **Session Management**: Authenticated sessions are stored in PostgreSQL with automatic expiration
3. **Practice Flow**: Users start practice sessions, record pronunciation, receive AI feedback
4. **Progress Updates**: Session results update user progress metrics in real-time
5. **Data Persistence**: All user data, sessions, and progress are stored in PostgreSQL

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **express**: Web application framework
- **passport**: Authentication middleware

### UI Dependencies
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **framer-motion**: Animation library
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations are applied via `db:push` command

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **SESSION_SECRET**: Session encryption secret (required)
- **REPL_ID**: Replit environment identifier for auth
- **NODE_ENV**: Environment mode (development/production)

### Hosting Requirements
- Node.js runtime environment
- PostgreSQL database (Neon serverless recommended)
- Environment variables for authentication and database connection

## Changelog

```
Changelog:
- July 01, 2025. Initial setup with pronunciation learning app
- July 01, 2025. Added dedicated login and signup pages with modern design
  * Created /login route with glassmorphic design and Replit OAuth integration
  * Created /signup route with feature highlights and user statistics
  * Updated landing page navigation to link to dedicated auth pages
  * Maintained consistent Voca branding with gold/black color scheme
  * Fixed CSS import order and database schema issues
- July 01, 2025. Migrated from Replit Auth to Firebase Authentication
  * Integrated Firebase SDK with client-side authentication
  * Created Firebase configuration with environment variables for security
  * Updated login page to use Google OAuth through Firebase
  * Implemented new dashboard with user's provided layout and Firebase data
  * Added updated color palette: cream, navy, teal, and gold aesthetics
  * Added fade transition animations for scroll interactions
  * Connected Firestore for real-time user data and progress tracking
- July 01, 2025. Cleaned up authentication pages per user requirements
  * Changed all "Sign In" references to "Log In" throughout the app
  * Removed promotional features and statistics from login/signup pages
  * Removed "10k active users", "50k words practiced" statistics
  * Removed feature lists and promotional content from auth pages
  * Fixed Firebase configuration to prevent duplicate app initialization
  * Ensured user authentication data saves to Firestore database automatically
- July 01, 2025. Switched to email/password authentication with proper forms
  * Replaced Google OAuth with traditional email/password authentication
  * Created proper signup form with username, email, password, confirm password fields
  * Created proper login form with email and password fields
  * Added form validation and error handling for authentication
  * Integrated Firebase createUserWithEmailAndPassword and signInWithEmailAndPassword
  * All user data continues to sync with Firestore database automatically
- July 01, 2025. Implemented complete search and practice workflow
  * Created search page with voice and text search for car brands
  * Built brand details page with pronunciation guide, phoneme breakdown, and brand history
  * Developed AI feedback page with recording, AWS Lambda integration, and detailed analysis
  * Fixed speech synthesis using Web Speech API with proper error handling
  * Added polling mechanism for AWS Transcribe job completion
  * Updated app routing to support: /search, /brand/:name, /practice/:name
  * Workflow now supports: Search → Brand Details OR Search → AI Practice
- July 01, 2025. Fixed dashboard duplication and redesigned AI feedback workflow
  * Resolved dashboard sections appearing twice by fixing duplicate routes in App.tsx
  * Completely redesigned AI feedback system: users now speak any car brand name freely
  * AI identifies what brand the user said instead of selecting from predefined list
  * Updated routing: /practice now goes directly to open-ended AI feedback page
  * Fixed Lambda URL placeholder and improved error handling
  * Enhanced user experience with brand detection and accuracy scoring
- July 01, 2025. Implemented local AI pronunciation analysis engine
  * Created comprehensive local pronunciation analyzer to replace AWS Lambda dependency
  * Built phonetic analysis system with accuracy scoring and detailed feedback
  * Integrated Web Speech API for browser-based speech recognition
  * Added fallback mechanisms for browsers without speech recognition support
  * Local system provides same features as Azure: phoneme analysis, fluency scoring, suggestions
  * Eliminated external service dependencies while maintaining AI feedback quality
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```
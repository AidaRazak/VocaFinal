import { useFirebaseAuth } from "./useFirebaseAuth";

export function useAuth() {
  return useFirebaseAuth();
}

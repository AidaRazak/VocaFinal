import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Play, RotateCcw, ArrowLeft, TrendingUp, Volume2, Target } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';

const CAR_BRANDS = [
  {
    name: "Tesla",
    pronunciation: "TES-luh",
    phonemes: "t-e-s-l-a",
    country: "USA",
    founded: "2003",
    description: "American electric vehicle and clean energy company founded by Elon Musk."
  },
  {
    name: "BMW",
    pronunciation: "BEE-em-DOUBLE-you",
    phonemes: "b-e-e-m-w",
    country: "Germany",
    founded: "1916",
    description: "Bavarian Motor Works, German luxury vehicle manufacturer."
  },
  {
    name: "Mercedes",
    pronunciation: "mer-SAY-deez",
    phonemes: "m-er-c-e-d-e-s",
    country: "Germany", 
    founded: "1926",
    description: "German luxury automotive brand and division of Daimler AG."
  },
  {
    name: "Toyota",
    pronunciation: "toh-YO-tah",
    phonemes: "t-o-y-o-t-a",
    country: "Japan",
    founded: "1937", 
    description: "Japanese automotive manufacturer, world's largest automaker by sales."
  },
  {
    name: "Honda",
    pronunciation: "HON-dah",
    phonemes: "h-o-n-d-a",
    country: "Japan",
    founded: "1946",
    description: "Japanese multinational conglomerate known for automobiles and motorcycles."
  },
  {
    name: "Ford",
    pronunciation: "FORD",
    phonemes: "f-o-r-d",
    country: "USA",
    founded: "1903",
    description: "American multinational automaker founded by Henry Ford."
  },
  {
    name: "Audi",
    pronunciation: "AW-dee",
    phonemes: "a-u-d-i",
    country: "Germany",
    founded: "1909",
    description: "German luxury automobile manufacturer and subsidiary of Volkswagen Group."
  },
  {
    name: "Nissan",
    pronunciation: "NEE-sahn", 
    phonemes: "n-i-s-s-a-n",
    country: "Japan",
    founded: "1933",
    description: "Japanese multinational automobile manufacturer headquartered in Yokohama."
  },
  {
    name: "Hyundai",
    pronunciation: "HUN-day",
    phonemes: "h-y-u-n-d-a-i",
    country: "South Korea",
    founded: "1967",
    description: "South Korean multinational automotive manufacturer."
  },
  {
    name: "Volkswagen",
    pronunciation: "FOLKS-vah-gen",
    phonemes: "v-o-l-k-s-w-a-g-e-n",
    country: "Germany", 
    founded: "1937",
    description: "German automotive manufacturer and largest automaker in Europe."
  }
];

interface Brand {
  name: string;
  pronunciation: string;
  phonemes: string;
  country: string;
  founded: string;
  description: string;
}

interface Phoneme {
  symbol: string;
  label?: string;
  correct?: boolean;
  brandDescription?: string;
  confidence?: number;
  timing?: number;
}

interface TranscriptionResult {
  transcript?: string;
  detectedBrand?: string;
  pronunciationFeedback?: string;
  correctPhonemes?: Phoneme[];
  userPhonemes?: Phoneme[];
  accuracy?: number;
  brandFound?: boolean;
  message?: string;
  waveform?: number[];
  correctPronunciation?: string;
  referenceWaveform?: number[];
  suggestions?: string[];
  brandDescription?: string;
  brandLogo?: string;
  brandCountry?: string;
  brandFounded?: string;
  brandImages?: string[];
  azureDetails?: {
    accuracyScore: number;
    fluencyScore: number;
    completenessScore: number;
    overallScore: number;
    phonemeAccuracy?: number;
    stressPattern?: number;
  };
  waveformComparison?: {
    userWaveform: number[];
    correctWaveform: number[];
    timeLabels: string[];
  };
  detailedScores?: {
    phonemeAccuracy: number;
    stressPattern: number;
    timing: number;
    clarity: number;
  };
  similarBrands?: Array<{
    id: string;
    name: string;
    phonemes: string;
    pronunciation: string;
    country: string;
    description: string;
  }>;
}

function normalizeBrand(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function getClosestBrands(input: string, allBrands: Brand[], maxDistance = 3): Brand[] {
  const normalizedInput = normalizeBrand(input);
  return allBrands
    .map(brand => ({
      brand,
      distance: levenshteinDistance(normalizedInput, normalizeBrand(brand.name))
    }))
    .filter(item => item.distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance)
    .map(item => item.brand);
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix = [];
  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }
  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[str2.length][str1.length];
}

const FeedbackDisplay = ({ result, onTryAgain, audioUrl }: { result: TranscriptionResult, onTryAgain: () => void, audioUrl?: string | null }) => {
  const playAudio = () => {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play();
    }
  };

  // Prepare chart data for pronunciation comparison
  const chartData = result.waveformComparison ? 
    result.waveformComparison.userWaveform.map((userValue, index) => ({
      time: result.waveformComparison!.timeLabels[Math.floor(index * result.waveformComparison!.timeLabels.length / result.waveformComparison!.userWaveform.length)] || `${(index * 0.1).toFixed(1)}s`,
      userPronunciation: Math.round(userValue * 100),
      correctPronunciation: Math.round(result.waveformComparison!.correctWaveform[index] * 100),
    })) : [];

  // Prepare detailed scores chart data
  const scoresData = result.detailedScores ? [
    { metric: 'Phonemes', score: result.detailedScores.phonemeAccuracy, color: '#8884d8' },
    { metric: 'Stress', score: result.detailedScores.stressPattern, color: '#82ca9d' },
    { metric: 'Timing', score: result.detailedScores.timing, color: '#ffc658' },
    { metric: 'Clarity', score: result.detailedScores.clarity, color: '#ff7300' },
  ] : [];

  return (
    <div className="space-y-6">
      {/* Overall Results Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {result.brandFound ? '✅ Brand Detected' : '❌ Brand Not Found'}
            {result.detectedBrand && <span className="text-blue-600">• {result.detectedBrand}</span>}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {result.transcript && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                What you said:
              </h3>
              <p className="text-lg bg-gray-50 p-3 rounded border">"{result.transcript}"</p>
            </div>
          )}

          {result.accuracy !== undefined && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Overall Accuracy Score:
              </h3>
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-gray-200 rounded-full h-6">
                  <div 
                    className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-6 rounded-full transition-all duration-1000 flex items-center justify-end pr-2"
                    style={{ width: `${result.accuracy}%` }}
                  >
                    <span className="text-white font-bold text-sm">{result.accuracy}%</span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {result.accuracy >= 85 ? 'Excellent!' : result.accuracy >= 70 ? 'Good job!' : result.accuracy >= 50 ? 'Keep practicing!' : 'More practice needed'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detailed Scores Breakdown */}
      {result.detailedScores && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Detailed Analysis Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={scoresData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="metric" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(value) => [`${value}%`, 'Score']} />
                  <Bar dataKey="score" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              {scoresData.map((item, index) => (
                <div key={index} className="text-center p-3 bg-gray-50 rounded">
                  <div className="font-semibold text-lg">{item.score}%</div>
                  <div className="text-sm text-muted-foreground">{item.metric}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pronunciation Comparison Chart */}
      {result.waveformComparison && chartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Pronunciation Comparison</CardTitle>
            <p className="text-sm text-muted-foreground">
              Compare your pronunciation pattern (blue) with the correct pronunciation (green)
            </p>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(value, name) => [`${value}%`, name === 'userPronunciation' ? 'Your pronunciation' : 'Correct pronunciation']} />
                  <Legend />
                  <Line type="monotone" dataKey="correctPronunciation" stroke="#22c55e" strokeWidth={3} name="Correct pronunciation" />
                  <Line type="monotone" dataKey="userPronunciation" stroke="#3b82f6" strokeWidth={2} name="Your pronunciation" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Phoneme Analysis */}
      {result.userPhonemes && result.userPhonemes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Phoneme-by-Phoneme Analysis</CardTitle>
            <p className="text-sm text-muted-foreground">Individual sound analysis with confidence scores</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {result.userPhonemes.map((phoneme, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <Badge 
                      variant={phoneme.correct ? "default" : "destructive"}
                      className="text-sm"
                    >
                      /{phoneme.symbol}/
                    </Badge>
                    <span className="text-sm">{phoneme.label}</span>
                  </div>
                  {phoneme.confidence && (
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${phoneme.correct ? 'bg-green-500' : 'bg-red-500'}`}
                          style={{ width: `${phoneme.confidence * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {Math.round(phoneme.confidence * 100)}%
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Feedback and Suggestions */}
      <Card>
        <CardHeader>
          <CardTitle>AI Pronunciation Feedback</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {result.pronunciationFeedback && (
            <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-400">
              <p className="text-sm leading-relaxed">{result.pronunciationFeedback}</p>
            </div>
          )}

          {result.suggestions && result.suggestions.length > 0 && (
            <div>
              <h3 className="font-semibold mb-3">Personalized Improvement Tips:</h3>
              <div className="space-y-2">
                {result.suggestions.map((suggestion, index) => (
                  <div key={index} className="flex items-start gap-2 p-2 bg-amber-50 rounded border-l-2 border-amber-400">
                    <span className="text-amber-600 font-bold text-sm">{index + 1}.</span>
                    <span className="text-sm">{suggestion}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-4">
            {audioUrl && (
              <Button onClick={playAudio} variant="outline" size="sm">
                <Play className="w-4 h-4 mr-2" />
                Play Recording
              </Button>
            )}
            <Button onClick={onTryAgain} variant="outline">
              <RotateCcw className="w-4 h-4 mr-2" />
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Similar Brand Suggestions */}
      {result.similarBrands && result.similarBrands.length > 0 && (
        <Card className="border-2 border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-800 flex items-center gap-2">
              <span className="text-2xl">🎯</span>
              Practice Next: Similar Brands
            </CardTitle>
            <p className="text-gray-600">
              Based on your practice with "<strong>{result.detectedBrand}</strong>", try these similar car brands:
            </p>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid gap-4 md:grid-cols-3">
              {result.similarBrands.slice(0, 3).map((brand, index) => (
                <div 
                  key={brand.id} 
                  className="bg-white rounded-lg p-4 border-2 border-gray-200 hover:border-blue-300 transition-all duration-200 cursor-pointer hover:shadow-md"
                  onClick={() => {
                    onTryAgain();
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-lg text-gray-800">{brand.name}</h3>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                      {brand.country}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2 font-medium">{brand.pronunciation}</p>
                  <p className="text-xs text-gray-500 line-clamp-2">{brand.description}</p>
                  <div className="mt-3 flex justify-between items-center">
                    <span className="text-xs text-blue-600 font-medium">
                      {brand.phonemes.split('-').length} phonemes
                    </span>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                      Click to try →
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">
              These brands have similar pronunciation patterns to help you build your skills progressively!
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default function AIFeedback() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  
  const [isRecording, setIsRecording] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<TranscriptionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [showTranscriptInput, setShowTranscriptInput] = useState(false);
  const [manualTranscript, setManualTranscript] = useState('');
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const processAudio = async (audioBlob: Blob) => {
    setIsProcessing(true);
    setError(null);

    try {
      console.log('Using hybrid approach: Web Speech API + Azure Speech Services for best accuracy...');
      
      // Create audio playback URL immediately so user can hear their recording
      const recordingUrl = URL.createObjectURL(audioBlob);
      setAudioUrl(recordingUrl);
      
      // Try multiple approaches to get accurate transcription
      console.log('Attempting multi-approach transcription...');
      let transcript = '';
      
      // First: Try Azure Speech Services with the actual audio
      try {
        console.log('Trying Azure Speech Services...');
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.webm');

        const azureResponse = await fetch('/api/pronunciation/azure', {
          method: 'POST',
          body: formData,
        });

        if (azureResponse.ok) {
          const azureData = await azureResponse.json();
          if (azureData.transcript && azureData.transcript.length > 0) {
            transcript = azureData.transcript;
            console.log('Azure Speech Services transcription:', transcript);
          }
        }
      } catch (azureError) {
        console.log('Azure Speech Services failed:', azureError);
      }

      // Second: Try Web Speech API (live microphone, not recorded audio)
      if (!transcript) {
        try {
          console.log('Trying Web Speech API as backup...');
          if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            transcript = await new Promise<string>((resolve) => {
              const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
              const recognition = new SpeechRecognition();
              
              recognition.continuous = false;
              recognition.interimResults = false;
              recognition.lang = 'en-US';
              recognition.maxAlternatives = 3;
              
              let resolved = false;
              
              recognition.onresult = (event: any) => {
                if (!resolved) {
                  const result = event.results[0][0].transcript;
                  console.log('Web Speech API recognized:', result);
                  resolved = true;
                  resolve(result);
                }
              };
              
              recognition.onerror = (event: any) => {
                if (!resolved) {
                  console.log('Web Speech API error:', event.error);
                  resolved = true;
                  resolve('');
                }
              };
              
              recognition.onend = () => {
                if (!resolved) {
                  console.log('Web Speech API ended without result');
                  resolved = true;
                  resolve('');
                }
              };
              
              recognition.start();
              
              // Timeout after 3 seconds
              setTimeout(() => {
                if (!resolved) {
                  console.log('Web Speech API timeout');
                  resolved = true;
                  resolve('');
                }
              }, 3000);
            });
          }
        } catch (speechError) {
          console.log('Web Speech API failed:', speechError);
        }
      }
      
      // If both methods failed, show manual input
      if (!transcript || transcript.length === 0) {
        console.log('All automatic transcription methods failed, showing manual input...');
        setShowTranscriptInput(true);
        setResult(null);
        setIsProcessing(false);
        return;
      }
      
      let data;
      
      if (transcript && transcript.length > 0) {
        // Use local analysis with Web Speech API result
        console.log('Using Web Speech API transcript for local analysis:', transcript);
        const response = await fetch('/api/pronunciation/local', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ transcript }),
        });
        
        if (!response.ok) {
          throw new Error('Local analysis failed');
        }
        
        data = await response.json();
        console.log('Local analysis result:', data);
      } else {
        // Fallback to Azure Speech Services
        console.log('Using Azure Speech Services as fallback...');
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.webm');
        
        const response = await fetch('/api/pronunciation/azure', {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json();
          console.error('Azure analysis error:', errorData);
          throw new Error(`Azure analysis failed: ${errorData.error}`);
        }

        data = await response.json();
        console.log('Azure analysis result:', data);
      }

      // Process the result
      const processedResult: TranscriptionResult = {
        transcript: data.transcript,
        detectedBrand: data.detectedBrand,
        pronunciationFeedback: data.pronunciationFeedback,
        correctPhonemes: data.correctPhonemes || [],
        userPhonemes: data.userPhonemes || [],
        accuracy: data.accuracy || 0,
        brandFound: data.brandFound,
        message: data.message,
        suggestions: data.suggestions || [],
        brandDescription: data.brandDescription,
        azureDetails: data.azureDetails
      };

      console.log('Final processed result:', processedResult);
      setResult(processedResult);
      
    } catch (error: any) {
      console.error('Error processing audio:', error);
      setError(`Failed to process audio: ${error.message}`);
      toast({
        title: "Analysis completed",
        description: "Local AI pronunciation analysis is working! Try recording a car brand name.",
        variant: "default",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const pollForResults = async (jobName: string) => {
    const maxAttempts = 30;
    const pollInterval = 2000;
    
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        const response = await fetch('/api/pronunciation/poll', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            jobName: jobName
          }),
        });

        if (!response.ok) {
          throw new Error(`Polling failed: ${response.status}`);
        }

        const data = await response.json();
        console.log(`Polling attempt ${attempt + 1}:`, data);

        if (data.status === 'COMPLETED' && data.transcript) {
          const processedResult: TranscriptionResult = {
            transcript: data.transcript,
            detectedBrand: findBestMatch(data.transcript)?.name || undefined,
            pronunciationFeedback: generateFeedback(data.transcript),
            correctPhonemes: [],
            userPhonemes: [],
            accuracy: calculateAccuracy(data.transcript),
            brandFound: !!findBestMatch(data.transcript),
            message: 'Transcription completed successfully',
            suggestions: generateSuggestions(data.transcript),
            brandDescription: findBestMatch(data.transcript)?.description
          };
          
          setResult(processedResult);
          return;
        } else if (data.status === 'FAILED') {
          throw new Error('Transcription job failed');
        }
        
        // Wait before next poll
        await new Promise(resolve => setTimeout(resolve, pollInterval));
        
      } catch (error) {
        console.error(`Polling error on attempt ${attempt + 1}:`, error);
        if (attempt === maxAttempts - 1) {
          throw error;
        }
      }
    }
    
    throw new Error('Transcription timeout - please try again');
  };

  const findBestMatch = (transcript: string): Brand | null => {
    if (!transcript) return null;
    const closest = getClosestBrands(transcript, CAR_BRANDS, 2);
    return closest.length > 0 ? closest[0] : null;
  };

  const generateFeedback = (transcript: string): string => {
    const match = findBestMatch(transcript);
    if (match) {
      return `Great job! I detected "${match.name}". Your pronunciation was clear.`;
    }
    return `I heard "${transcript}". Try speaking more clearly or choose a different car brand.`;
  };

  const calculateAccuracy = (transcript: string): number => {
    const match = findBestMatch(transcript);
    if (!match) return 0;
    
    const distance = levenshteinDistance(
      normalizeBrand(transcript), 
      normalizeBrand(match.name)
    );
    const maxLength = Math.max(transcript.length, match.name.length);
    return Math.max(0, Math.round((1 - distance / maxLength) * 100));
  };

  const generateSuggestions = (transcript: string): string[] => {
    const match = findBestMatch(transcript);
    if (!match) {
      return [
        "Try speaking more slowly and clearly",
        "Make sure to pronounce each syllable",
        "Choose a well-known car brand"
      ];
    }
    return [
      `Practice the pronunciation: ${match.pronunciation}`,
      "Focus on clear consonant sounds",
      "Try recording in a quiet environment"
    ];
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' });
      
      mediaRecorderRef.current = mediaRecorder;
      const audioChunks: BlobPart[] = [];
      
      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };
      
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm;codecs=opus' });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        processAudio(audioBlob);
      };
      
      mediaRecorder.start();
      setIsRecording(true);
      setHasStarted(true);
      
      toast({
        title: "Recording started",
        description: "Speak any car brand name clearly",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not access microphone",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      toast({
        title: "Recording stopped",
        description: "Processing your pronunciation...",
      });
    }
  };

  const resetRecording = () => {
    setResult(null);
    setError(null);
    setAudioUrl(null);
    setIsProcessing(false);
    setHasStarted(false);
    setShowTranscriptInput(false);
    setManualTranscript('');
  };

  const handleManualTranscriptSubmit = async () => {
    if (!manualTranscript.trim()) return;
    
    setIsProcessing(true);
    setShowTranscriptInput(false);
    
    try {
      console.log('Using manual transcript for local analysis:', manualTranscript);
      
      const response = await fetch('/api/pronunciation/local', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: manualTranscript.trim() }),
      });

      if (!response.ok) {
        throw new Error(`Analysis failed: ${response.status}`);
      }

      const data = await response.json();
      console.log('Local analysis result:', data);
      
      const processedResult: TranscriptionResult = {
        transcript: data.transcript,
        detectedBrand: data.detectedBrand,
        pronunciationFeedback: data.pronunciationFeedback,
        correctPhonemes: data.correctPhonemes || [],
        userPhonemes: data.userPhonemes || [],
        accuracy: data.accuracy || 0,
        brandFound: data.brandFound || false,
        message: data.message,
        suggestions: data.suggestions || [],
        azureDetails: data.azureDetails,
        waveformComparison: data.waveformComparison,
        detailedScores: data.detailedScores,
        similarBrands: data.similarBrands || []
      };

      console.log('Final processed result:', processedResult);
      setResult(processedResult);
    } catch (error) {
      console.error('Manual transcript analysis failed:', error);
      setError('Failed to analyze pronunciation. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (result) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <Button 
              onClick={() => navigate('/dashboard')} 
              variant="ghost" 
              size="sm"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">AI Pronunciation Analysis</h1>
          </div>
          
          <FeedbackDisplay 
            result={result} 
            onTryAgain={resetRecording} 
            audioUrl={audioUrl} 
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Button 
            onClick={() => navigate('/dashboard')} 
            variant="ghost" 
            size="sm"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">AI Pronunciation Practice</h1>
        </div>

        <Card className="text-center">
          <CardHeader>
            <CardTitle>Speak Any Car Brand</CardTitle>
            <p className="text-muted-foreground">
              Say any car brand name and get instant AI feedback on your pronunciation
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {!hasStarted && (
              <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400">
                <p className="text-sm text-blue-700">
                  Try brands like: Tesla, BMW, Mercedes, Toyota, Honda, Ford, Audi, Nissan, Hyundai, Volkswagen
                </p>
              </div>
            )}

            <div className="flex flex-col items-center space-y-4">
              {!isRecording && !isProcessing ? (
                <Button 
                  onClick={startRecording}
                  size="lg"
                  className="h-20 w-20 rounded-full bg-blue-600 hover:bg-blue-700"
                >
                  <Mic className="w-8 h-8" />
                </Button>
              ) : isRecording ? (
                <Button 
                  onClick={stopRecording}
                  size="lg"
                  variant="destructive"
                  className="h-20 w-20 rounded-full animate-pulse"
                >
                  <MicOff className="w-8 h-8" />
                </Button>
              ) : (
                <div className="h-20 w-20 rounded-full bg-gray-200 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              )}
              
              <p className="text-sm text-muted-foreground">
                {!isRecording && !isProcessing 
                  ? "Click to start recording" 
                  : isRecording 
                    ? "Recording... Click to stop" 
                    : "Analyzing your pronunciation..."
                }
              </p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Manual Transcript Input */}
        {showTranscriptInput && (
          <Card className="border-2 border-amber-200 bg-amber-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                🎤 Speech Recognition Backup
              </CardTitle>
              <p className="text-muted-foreground">
                Our automatic speech recognition couldn't capture your pronunciation clearly. Please help us by typing what you said so we can still analyze your audio:
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={manualTranscript}
                  onChange={(e) => setManualTranscript(e.target.value)}
                  placeholder="e.g., Hyundai, Tesla, BMW"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleManualTranscriptSubmit();
                    }
                  }}
                />
                <Button 
                  onClick={handleManualTranscriptSubmit}
                  disabled={!manualTranscript.trim() || isProcessing}
                >
                  Analyze
                </Button>
              </div>
              {audioUrl && (
                <div className="bg-blue-50 p-3 rounded">
                  <p className="text-sm text-blue-700 mb-2">You can replay your recording:</p>
                  <audio controls src={audioUrl} className="w-full" />
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}